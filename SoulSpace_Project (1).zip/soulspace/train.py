"""
SoulSpace Pipeline Training Script
Trains TF-IDF + Multinomial Logistic Regression pipeline on emotional reflections corpus.
"""

import os
import argparse
import pandas as pd
import numpy as np
import joblib

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

from preprocess import clean_text

def build_pipeline(c_reg: float = 1.0, max_features: int = 5000) -> Pipeline:
    return Pipeline([
        ('tfidf', TfidfVectorizer(
            ngram_range=(1, 2),
            max_features=max_features,
            sublinear_tf=True,
            min_df=1
        )),
        ('clf', LogisticRegression(
            C=c_reg,
            penalty='l2',
            solver='lbfgs',
            max_iter=1000,
            multi_class='multinomial',
            class_weight='balanced',
            random_state=42
        ))
    ])

def train(data_path: str, test_size: float = 0.2, c_reg: float = 1.0, output_dir: str = "models"):
    print(f"[INFO] Ingesting emotional corpus from: {data_path}")
    df = pd.read_csv(data_path)
    df['clean_text'] = df['text'].apply(clean_text)
    
    X_train, X_test, y_train, y_test = train_test_split(
        df['clean_text'], df['sentiment'],
        test_size=test_size,
        stratify=df['sentiment'],
        random_state=42
    )
    
    pipeline = build_pipeline(c_reg=c_reg)
    pipeline.fit(X_train, y_train)
    
    y_pred = pipeline.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    
    print(f"\n--- SoulSpace Model Evaluation (Accuracy: {acc*100:.2f}%) ---")
    print(classification_report(y_test, y_pred, digits=4))
    
    os.makedirs(output_dir, exist_ok=True)
    save_path = os.path.join(output_dir, "soulspace_pipeline.joblib")
    joblib.dump(pipeline, save_path)
    print(f"[SUCCESS] Model artifact saved to: {save_path}")
    return pipeline

def train_default_pipeline():
    curr = os.path.dirname(__file__)
    return train(os.path.join(curr, "dataset.csv"), output_dir=os.path.join(curr, "models"))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="dataset.csv")
    parser.add_argument("--c", type=float, default=1.0)
    args = parser.parse_args()
    train(args.data, c_reg=args.c)
