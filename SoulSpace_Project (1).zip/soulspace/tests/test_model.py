"""
SoulSpace Automated Pytest Suite
"""

import pytest
import numpy as np
from preprocess import clean_text
from train import build_pipeline

def test_clean_text_preserves_negations():
    raw = "I am not broken and will never surrender to despair."
    cleaned = clean_text(raw)
    assert "not" in cleaned
    assert "never" in cleaned

def test_empty_reflection_handling():
    assert clean_text("") == ""
    assert clean_text(None) == ""

def test_pipeline_prediction():
    train_texts = [
        "deep peace gratitude and sunlight",
        "joyful laughter and warm connection",
        "suffocating panic and racing thoughts",
        "overwhelmed exhausted and drained",
        "watching rain by the window silently",
        "breathing at six cycles per minute"
    ]
    labels = ["positive", "positive", "negative", "negative", "neutral", "neutral"]
    
    pipe = build_pipeline(c_reg=1.0)
    pipe.fit(train_texts, labels)
    
    res = pipe.predict(["feeling deep peace"])[0]
    assert res == "positive"
