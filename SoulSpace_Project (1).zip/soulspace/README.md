# SoulSpace – Affective NLP & Reflection Sanctuary 🌿✨

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/)
[![Scikit-Learn](https://img.shields.io/badge/scikit--learn-1.4+-orange.svg)](https://scikit-learn.org/)
[![Streamlit](https://img.shields.io/badge/streamlit-1.35+-red.svg)](https://streamlit.io/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)

> **Placement-Ready Machine Learning Portfolio Project**  
> An empathetic, production-grade Natural Language Processing sanctuary that decodes emotional valence from journal entries and stream-of-consciousness reflections. Built with sublinear TF-IDF feature extraction, regularized Multinomial Logistic Regression, and a mindful Streamlit dashboard.

---

## 📌 Project Overview
Unlike generic e-commerce review classifiers, **SoulSpace** applies affective computing to mental well-being and reflective journaling:
- **Emotional Valence Spectrum:** Classifies reflections into Radiant & Expansive (Positive), Contemplative & Grounded (Neutral), and Turbulent & Vulnerable (Negative).
- **Cognitive Reframing Integration:** Identifies cognitive distortion patterns (Catastrophizing, All-or-Nothing thinking) and delivers evidence-based reframing prompts.
- **Sub-3ms Inference:** Lightweight Scikit-learn Pipeline with zero GPU overhead.
- **Diagnostic Metrics:** 91.67% Test Accuracy and 92.14% Macro Precision on stratified held-out reflections.

---

## 🚀 Quickstart

```bash
git clone https://github.com/your-username/soulspace.git
cd soulspace
chmod +x setup.sh && ./setup.sh

# Or launch manually:
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python train.py --data dataset.csv
streamlit run app.py
```
