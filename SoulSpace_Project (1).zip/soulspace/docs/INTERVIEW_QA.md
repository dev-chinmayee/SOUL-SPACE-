# SoulSpace – Technical Interview Defense Guide 🎓

### Q1: Why build SoulSpace for emotional reflections instead of generic product reviews?
**Answer:**
Recruiters and senior engineers see thousands of identical "Amazon review scraper" projects. SoulSpace demonstrates **domain-specific affective computing**, handling nuanced human sentiment, vulnerability markers, and cognitive distortions. It proves understanding of real-world NLP where semantic inversion ("not broken") and subtle neutral contemplation ("just sitting watching rain") require sophisticated feature engineering.

### Q2: How does the pipeline preserve emotional valence during stopword removal?
**Answer:**
Standard stopword libraries discard "not", "never", "no", and "hardly". If a user writes "I am not broken", standard preprocessing strips "not", leaving only "broken" with high negative weight! SoulSpace implements a curated whitelist of valence inverters and extracts bigrams via TF-IDF (1, 2) so "not_broken" receives its own distinct positive/grounded coefficient.
