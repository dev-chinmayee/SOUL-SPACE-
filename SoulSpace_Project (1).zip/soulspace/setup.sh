#!/usr/bin/env bash
set -e
echo "🌿 Setting up SoulSpace environment..."
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
python train.py --data dataset.csv
pytest tests/ -v
echo "✨ SoulSpace is ready! Run: streamlit run app.py"
